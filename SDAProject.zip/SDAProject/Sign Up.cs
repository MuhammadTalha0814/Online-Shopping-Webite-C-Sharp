﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDAProject
{
    public partial class Sign_Up : Form
    {
        int pid;
        public Sign_Up(int p)
        {
            InitializeComponent();
            pid = p;
        }

        private void SignUP_Click(object sender, EventArgs e)
        {
            bool flag = true;

            DTO std = new DTO();

            if (FIRSTNAME.Text == "")
            {
                MessageBox.Show("Please Enter The Required Field");
                flag = false;
            }
            else
            {
                std._firstname = FIRSTNAME.Text;
            }


            if (flag == true)
            {
                if (LASTNAME.Text == "")
                {
                    MessageBox.Show("Please Enter The Required Field");
                    flag = false;
                }
                else
                {
                    std._lastName = LASTNAME.Text;
                }
            }

            if (flag == true)
            {
                if (USERNAME.Text == "")
                {
                    MessageBox.Show("Please Enter The Required Field");
                    flag = false;
                }
                else
                {
                    std._EmailAddress = USERNAME.Text;
                }
            }


            if (flag == true)
            {
                if (PASSWORD.Text == "")
                {
                    MessageBox.Show("Please Enter The Required Field");
                    flag = false;
                }
                else
                {
                    std._password = PASSWORD.Text;
                }
            }

            if (flag == true)
            {
                if (PHONE.Text == "")
                {
                    MessageBox.Show("Please Enter The Required Field");
                    flag = false;
                }
                else
                {
                    std._phone = PHONE.Text;
                }

            }


           
            if (flag == true)
            {
                DL.addstd(std);
                MessageBox.Show("User succesfully registered");

                FIRSTNAME.Clear();
                LASTNAME.Clear();
                USERNAME.Clear();
                PASSWORD.Clear();
                PHONE.Clear();
                
                Form1 h = new Form1(pid);
                this.Hide();
                h.Show();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 h = new Form1(pid);
            this.Hide();
            h.Show();
        }

        private void SIGNINMOVING_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Home h = new Home(pid);
            this.Hide();
            h.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }
    }
}
