﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SDAProject
{
    
    public partial class Confirm_Sign_In : Form
    {
        int pe;
        public Confirm_Sign_In(int pid)
        {
            pe = pid;
            InitializeComponent();
        }

        private void LOGO_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1(pe);
            this.Hide();
            f.Show();
        }

        private void Register_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up f = new Sign_Up(pe);
            this.Hide();
            f.Show();
        }

        private void MoveToSignIn_Click(object sender, EventArgs e)
        {
            string emailcheck = "{";
            string passwordcheck = "{";
            bool flag = false;
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand cmd;
            MySqlDataReader mdr;

            connection.Open();

            string query = "SELECT * FROM customers WHERE email='" + USERNAME.Text + "'";
            cmd = new MySqlCommand(query, connection);

            mdr = cmd.ExecuteReader();

            if (mdr.Read())
            {
                emailcheck = mdr.GetString("email");
                passwordcheck = mdr.GetString("password");
                flag = true;
            }
            else
            {
                MessageBox.Show("No Record Of This ID");

            }
            if (flag == true)
            {
                if (emailcheck == USERNAME.Text && passwordcheck == PASSWORD.Text)
                {

                    Buy_Now form = new Buy_Now(emailcheck,pe);
                    this.Hide();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("User is Invalid");
                }
            }

            connection.Close();

            USERNAME.Clear();
            PASSWORD.Clear();
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Product_Details p = new Product_Details(pe);
            this.Hide();
            p.Show();
        }

        private void LOGO_Click_1(object sender, EventArgs e)
        {
            Form1 f = new Form1(pe);
            this.Hide();
            f.Show();
        }

        private void Register_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up s = new Sign_Up(pe);
            this.Hide();
            s.Show();
        }
    }
}
