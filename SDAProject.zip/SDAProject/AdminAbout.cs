﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class AdminAbout : Form
    {
        public AdminAbout()
        {
            InitializeComponent();
            MySqlConnection connection2 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command2;
            MySqlDataAdapter da2;

            String selectQuery2 = "SELECT* FROM about";

            command2 = new MySqlCommand(selectQuery2, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table2 = new DataTable();

            da2.Fill(table2);
          
            d1.Text = table2.Rows[0][0].ToString();
            da2.Dispose();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminSignIn h = new AdminSignIn(0);
            this.Hide();
            h.Show();
            h.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminDeals a = new AdminDeals();
            this.Hide();
            a.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminHome h = new AdminHome();
            this.Hide();
            h.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            String insertQuery = "DELETE FROM about;";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();

            insertQuery = "INSERT INTO about(Description) VALUES(@desc)";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);

            command.Parameters.Add("@desc", MySqlDbType.Text);
            command.Parameters["@desc"].Value = d1.Text;
            if (command.ExecuteNonQuery() == 1)
            {

            }
            connection.Close();
            MessageBox.Show("Changed\n");
        }
    }
}

