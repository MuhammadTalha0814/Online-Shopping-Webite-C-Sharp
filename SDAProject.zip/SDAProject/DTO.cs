﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace SDAProject
{
    internal class DTO
    {
        public string _firstname;
        public string _lastName;
        public string _EmailAddress;
        public string _password;
        public string _phone;

        public string Firstname
        {
            set
            {
                _firstname = value;
            }
            get
            {
                return _firstname;
            }
        }

        public string LastName
        {
            set
            {
                _lastName = value;
            }
            get
            {
                return _lastName;
            }
        }

        public string EmailAddress
        {
            set
            {
                _EmailAddress = value;
            }
            get
            {
                return _EmailAddress;
            }
        }

        public string Password
        {
            set
            {
                _password = value;
            }
            get
            {
                return _password;
            }
        }
        public string Phone
        {
            set
            {
                _phone = value;
            }
            get
            {
                return _phone;
            }
        }


    }
}
