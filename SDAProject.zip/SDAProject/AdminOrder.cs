﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class AdminOrder : Form
    {
        
        public AdminOrder()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.DataSource = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=eMart";
            using (MySqlConnection sqlcon = new MySqlConnection(connectionString))
            {
                sqlcon.Open();
                MySqlDataAdapter sqlad = new MySqlDataAdapter("SELECT * FROM order_place ", sqlcon);
                DataTable student = new DataTable();
                sqlad.Fill(student);
                dataGridView1.DataSource = student;
                sqlcon.Close();
            }
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminDeals d = new AdminDeals();
            this.Hide();
            d.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            AdminHome d = new AdminHome();
            this.Hide();
            d.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminHome d = new AdminHome();
            this.Hide();
            d.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminSignIn f = new AdminSignIn(0);
            this.Hide();
            f.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminAbout a = new AdminAbout();
            this.Hide();
            a.Show();
        }
    }
    
}
