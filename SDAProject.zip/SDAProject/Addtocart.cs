﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class Addtocart : Form
    {
        int pid;
        public Addtocart(int p)
        {
            InitializeComponent();
            pid = p;

            MySqlConnection connection2 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command2;
            MySqlDataAdapter da2;

            String selectQuery2 = "SELECT* FROM AddtoCart where  tempid=1" ;

            command2 = new MySqlCommand(selectQuery2, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table2 = new DataTable();


            da2.Fill(table2);

            byte[] img2 = (byte[])table2.Rows[0][3];
            MemoryStream ms2 = new MemoryStream(img2);
            pictureBox2.Image = Image.FromStream(ms2);
            l1.Text = table2.Rows[0][1].ToString();
            da2.Dispose();


           string selectQuery3 = "SELECT* FROM AddtoCart where  tempid=2";

            command2 = new MySqlCommand(selectQuery3, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table3 = new DataTable();

            da2.Fill(table3);

            byte[] img3 = (byte[])table3.Rows[0][3];
            MemoryStream ms3 = new MemoryStream(img3);
            pictureBox4.Image = Image.FromStream(ms3);
            l2.Text = table3.Rows[0][1].ToString();
            da2.Dispose();



            string selectQuery4 = "SELECT* FROM AddtoCart where  tempid=3";

            command2 = new MySqlCommand(selectQuery4, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table4 = new DataTable();

            da2.Fill(table4);

            byte[] img4 = (byte[])table3.Rows[0][3];
            MemoryStream ms4 = new MemoryStream(img4);
            pictureBox5.Image = Image.FromStream(ms4);
            l3.Text = table4.Rows[0][1].ToString();
            da2.Dispose();




            string selectQuery5 = "SELECT* FROM AddtoCart where  tempid=4";

            command2 = new MySqlCommand(selectQuery5, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table5 = new DataTable();

            da2.Fill(table5);

            byte[] img5 = (byte[])table3.Rows[0][3];
            MemoryStream ms5 = new MemoryStream(img5);
            pictureBox6.Image = Image.FromStream(ms5);
            l4.Text = table5.Rows[0][1].ToString();
            da2.Dispose();




            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            MySqlDataAdapter da;

            String selectQuery = "SELECT* FROM picture where id=" + pid;

            command = new MySqlCommand(selectQuery, connection);

            da = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            da.Fill(table);

            
            byte[] img = (byte[])table.Rows[0][4];



            MySqlConnection connection1 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command1;

            string insertQuery = "INSERT INTO AddtoCart(tempid,id,name,pic) VALUES(@ti,@pid,@fn,@img)";
            connection1.Open();
            command1 = new MySqlCommand(insertQuery, connection1);

            command1.Parameters.Add("@ti", MySqlDbType.VarChar, 200);
            command1.Parameters.Add("@fn", MySqlDbType.VarChar, 200);
            command1.Parameters.Add("@pid", MySqlDbType.VarChar, 200);         
            command1.Parameters.Add("@img", MySqlDbType.Blob);

            command1.Parameters["@fn"].Value = table.Rows[0][1].ToString();
            
            command1.Parameters["@pid"].Value = pid;
            command1.Parameters["@img"].Value = img;


           
            MemoryStream ms = new MemoryStream(img);

            if (pictureBox2.Image == null)
            {
                pictureBox2.Image = Image.FromStream(ms);
                l1.Text = table.Rows[0][1].ToString();
                command1.Parameters["@ti"].Value = "1";

            }
            else if (pictureBox4.Image == null)
            {
                pictureBox4.Image = Image.FromStream(ms);
                l2.Text = table.Rows[0][1].ToString();
                command1.Parameters["@ti"].Value = "2";
            }
            else if (pictureBox5.Image == null)
            {
                pictureBox5.Image = Image.FromStream(ms);
                l3.Text = table.Rows[0][1].ToString();
                command1.Parameters["@ti"].Value = "3";
            }
            else if (pictureBox6.Image == null)
            {
                pictureBox6.Image = Image.FromStream(ms);
                l4.Text = table.Rows[0][1].ToString();
                command1.Parameters["@ti"].Value = "4";
            }
            else MessageBox.Show("Cart is Full");



            if (command1.ExecuteNonQuery() == 1)
            {

            }

            connection1.Close();


            da.Dispose();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home h = new Home(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Sign_Up h = new Sign_Up(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DailyDeals d = new DailyDeals(pid);
            this.Hide();
            d.Show();
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 d = new Form1(pid);
            this.Hide();
            d.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 d = new Form1(pid);
            this.Hide();
            d.Show();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DailyDeals d = new DailyDeals(pid);
            this.Hide();
            d.Show();
        }

       

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }
    }
}
