﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class Product_Details : Form
    {

        int p,pe; 
        public Product_Details(int pid)
        {           
            InitializeComponent();
            pe=p = pid;
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            MySqlDataAdapter da;
           
            String selectQuery = "SELECT* FROM picture where id=" + pid;

            command = new MySqlCommand(selectQuery, connection);

            da = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            da.Fill(table);

            NAME.Text = table.Rows[0][1].ToString();
            DESC.Text = table.Rows[0][2].ToString();
            byte[] img = (byte[])table.Rows[0][4];

            MemoryStream ms = new MemoryStream(img);

            pictureBox1.Image = Image.FromStream(ms);

            da.Dispose();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void Show_Click(object sender, EventArgs e)
        {
           

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void Show_Click_1(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 p = new Form1(pe);
            this.Hide();
            p.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(quantitybox.Text=="1" || quantitybox.Text == "2" || quantitybox.Text == "3" || quantitybox.Text == "4" || quantitybox.Text == "5")
            {

                string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=eMart";
                string query = "UPDATE picture SET quantity='" + quantitybox.Text + "' WHERE id='"+p +"';";
                MySqlConnection databaseconnection = new MySqlConnection(connectionString);
                MySqlCommand commandDatabase = new MySqlCommand(query, databaseconnection);
                commandDatabase.CommandTimeout = 60;
                MySqlDataReader reader;
                try
                {
                    databaseconnection.Open();
                    reader = commandDatabase.ExecuteReader();



                }
                catch (Exception ex)
                {
                   //Show any error message.
                    MessageBox.Show(ex.Message);
                }
                databaseconnection.Close();
                MessageBox.Show("Please Confirm Your Account");

                Confirm_Sign_In b = new Confirm_Sign_In(p);
                this.Hide();
                b.Show();
            }
           else MessageBox.Show("You can Only Buy Maximum 5 Products");
        }

      
    }
}
