﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDAProject
{
    public partial class AdminSignIn : Form
    {
        int pid;
        public AdminSignIn(int p)
        {
            InitializeComponent();
            pid = p;
        }

        private void LOGO_Click(object sender, EventArgs e)
        {
            Form1 h = new Form1(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home h = new Home(pid);
            this.Hide();
            h.Show();
        }

        private void MoveToSignIn_Click(object sender, EventArgs e)
        {
            if (USERNAME.Text == "muhammad14702@gmail.com" && PASSWORD.Text == "mtsstyle")
            {
                AdminHome h = new AdminHome();
                this.Hide();
                h.Show();
            }
            else MessageBox.Show("Invalid Id or Password");
        }
    }
}
