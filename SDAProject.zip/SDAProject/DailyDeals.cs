﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;


namespace SDAProject
{
    public partial class DailyDeals : Form
    {
        int pid;
        public DailyDeals(int p)
        {
            InitializeComponent();
            pid = p;
            MySqlConnection connection2 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command2;
            MySqlDataAdapter da2;

            String selectQuery2 = "SELECT* FROM picture where  id=5";

            command2 = new MySqlCommand(selectQuery2, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table2 = new DataTable();

            da2.Fill(table2);

            byte[] img2 = (byte[])table2.Rows[0][4];
            MemoryStream ms2 = new MemoryStream(img2);
            p1.Image = Image.FromStream(ms2);
            n1.Text = table2.Rows[0][1].ToString();
            pr1.Text = table2.Rows[0][5].ToString();
            d1.Text = table2.Rows[0][2].ToString();
            da2.Dispose();


            string selectQuery3 = "SELECT* FROM picture where  id=6";

            command2 = new MySqlCommand(selectQuery3, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table3 = new DataTable();

            da2.Fill(table3);

            byte[] img3 = (byte[])table3.Rows[0][4];
            MemoryStream ms3 = new MemoryStream(img3);
            p2.Image = Image.FromStream(ms3);
            n2.Text = table3.Rows[0][1].ToString();
            pr2.Text = table3.Rows[0][5].ToString();
            d2.Text = table3.Rows[0][2].ToString();
            da2.Dispose();




            string selectQuery4 = "SELECT* FROM picture where  id=7";

            command2 = new MySqlCommand(selectQuery4, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table4 = new DataTable();

            da2.Fill(table4);

            byte[] img4 = (byte[])table4.Rows[0][4];
            MemoryStream ms4 = new MemoryStream(img4);
            p3.Image = Image.FromStream(ms4);
            n3.Text = table4.Rows[0][1].ToString();
            d3.Text = table4.Rows[0][2].ToString();
            pr3.Text = table4.Rows[0][5].ToString();

            da2.Dispose();

            string selectQuery5 = "SELECT* FROM picture where  id=8";

            command2 = new MySqlCommand(selectQuery5, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table5 = new DataTable();

            da2.Fill(table5);

            byte[] img5 = (byte[])table5.Rows[0][4];
            MemoryStream ms5 = new MemoryStream(img5);
            p4.Image = Image.FromStream(ms5);
            n4.Text = table5.Rows[0][1].ToString();
            pr4.Text = table5.Rows[0][5].ToString();
            d4.Text = table5.Rows[0][2].ToString();
            da2.Dispose();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home h = new Home(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up h = new Sign_Up(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        
        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 h = new Form1(pid);
            this.Hide();
            h.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 h = new Form1(pid);
            this.Hide();
            h.Show();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.Show();
        }

        

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void p1_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            p1.Image.Save(ms, p1.Image.RawFormat);
            byte[] img = ms.ToArray();
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            String insertQuery = "DELETE FROM picture WHERE id=5;";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();

            insertQuery = "INSERT INTO picture(id,name,quantity,address,price,Description) VALUES(@id,@name,@qth,@img,@pri,@desc)";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);

            command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
            command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
            command.Parameters.Add("@desc", MySqlDbType.VarChar, 20);

            command.Parameters.Add("@qth", MySqlDbType.Int64);
            command.Parameters.Add("@pri", MySqlDbType.Int64);
            command.Parameters.Add("@img", MySqlDbType.Blob);

            command.Parameters["@id"].Value = pid = 5;
            command.Parameters["@name"].Value = n1.Text;
            command.Parameters["@pri"].Value = pr1.Text;
            command.Parameters["@desc"].Value = d1.Text;
            command.Parameters["@img"].Value = img;


            if (command.ExecuteNonQuery() == 1)
            {

            }
            connection.Close();

            Product_Details p = new Product_Details(pid);
            this.Hide();

            p.Show();
        }

        private void p2_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            p2.Image.Save(ms, p2.Image.RawFormat);
            byte[] img = ms.ToArray();
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            String insertQuery = "DELETE FROM picture WHERE id=6;";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();


            insertQuery = "INSERT INTO picture(id,name,quantity,address,price,Description) VALUES(@id,@name,@qth,@img,@pri,@desc)";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);

            command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
            command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
            command.Parameters.Add("@desc", MySqlDbType.VarChar, 20);

            command.Parameters.Add("@qth", MySqlDbType.Int64);
            command.Parameters.Add("@pri", MySqlDbType.Int64);
            command.Parameters.Add("@img", MySqlDbType.Blob);

            command.Parameters["@id"].Value = pid = 6;
            command.Parameters["@name"].Value = n2.Text;
            command.Parameters["@pri"].Value = pr2.Text;
            command.Parameters["@desc"].Value = d2.Text;
            command.Parameters["@img"].Value = img;


            if (command.ExecuteNonQuery() == 1)
            {

            }


            connection.Close();

            Product_Details p = new Product_Details(pid);
            this.Hide();

            p.Show();

        }

        private void p3_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            p3.Image.Save(ms, p3.Image.RawFormat);
            byte[] img = ms.ToArray();
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            String insertQuery = "DELETE FROM picture WHERE id=7;";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();


            insertQuery = "INSERT INTO picture(id,name,quantity,address,price,Description) VALUES(@id,@name,@qth,@img,@pri,@desc)";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);

            command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
            command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
            command.Parameters.Add("@desc", MySqlDbType.VarChar, 20);

            command.Parameters.Add("@qth", MySqlDbType.Int64);
            command.Parameters.Add("@pri", MySqlDbType.Int64);
            command.Parameters.Add("@img", MySqlDbType.Blob);

            command.Parameters["@id"].Value = pid = 7;
            command.Parameters["@name"].Value = n3.Text;
            command.Parameters["@pri"].Value = pr3.Text;
            command.Parameters["@desc"].Value = d3.Text;
            command.Parameters["@img"].Value = img;


            if (command.ExecuteNonQuery() == 1)
            {

            }


            connection.Close();

            Product_Details p = new Product_Details(pid);
            this.Hide();

            p.Show();
        }

        private void p4_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            p4.Image.Save(ms, p4.Image.RawFormat);
            byte[] img = ms.ToArray();
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            String insertQuery = "DELETE FROM picture WHERE id=8;";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();


            insertQuery = "INSERT INTO picture(id,name,quantity,address,price,Description) VALUES(@id,@name,@qth,@img,@pri,@desc)";
            connection.Open();
            command = new MySqlCommand(insertQuery, connection);

            command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
            command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
            command.Parameters.Add("@desc", MySqlDbType.VarChar, 20);

            command.Parameters.Add("@qth", MySqlDbType.Int64);
            command.Parameters.Add("@pri", MySqlDbType.Int64);
            command.Parameters.Add("@img", MySqlDbType.Blob);

            command.Parameters["@id"].Value = pid = 8;
            command.Parameters["@name"].Value = n4.Text;
            command.Parameters["@pri"].Value = pr4.Text;
            command.Parameters["@desc"].Value = d4.Text;
            command.Parameters["@img"].Value = img;


            if (command.ExecuteNonQuery() == 1)
            {

            }


            connection.Close();

            Product_Details p = new Product_Details(pid);
            this.Hide();

            p.Show();

        }
        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            About a = new About(pid);
            this.Hide();
            a.Show();
        }
    }
}
