﻿namespace SDAProject
{
    partial class DailyDeals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.d4 = new System.Windows.Forms.Label();
            this.d3 = new System.Windows.Forms.Label();
            this.d2 = new System.Windows.Forms.Label();
            this.d1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.n2 = new System.Windows.Forms.Label();
            this.pr2 = new System.Windows.Forms.Label();
            this.n3 = new System.Windows.Forms.Label();
            this.pr4 = new System.Windows.Forms.Label();
            this.n4 = new System.Windows.Forms.Label();
            this.pr3 = new System.Windows.Forms.Label();
            this.n1 = new System.Windows.Forms.Label();
            this.pr1 = new System.Windows.Forms.Label();
            this.p4 = new System.Windows.Forms.PictureBox();
            this.p1 = new System.Windows.Forms.PictureBox();
            this.p3 = new System.Windows.Forms.PictureBox();
            this.p2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SDAProject.Properties.Resources.pexels_hassan_ouajbir_1860160;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 505);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(10, 404);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(776, 88);
            this.panel6.TabIndex = 10;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SDAProject.Properties.Resources.norton_logo;
            this.pictureBox3.Location = new System.Drawing.Point(335, 34);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 47);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(123, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(537, 26);
            this.label5.TabIndex = 8;
            this.label5.Text = "Copyright © 1995-2022 eBay Inc. All Rights Reserved. Accessibility, User Agreemen" +
    "t, Privacy, Cookies,\r\n                                                Do not sel" +
    "l my personal information and AdChoice";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.d4);
            this.panel5.Controls.Add(this.d3);
            this.panel5.Controls.Add(this.d2);
            this.panel5.Controls.Add(this.d1);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.n2);
            this.panel5.Controls.Add(this.pr2);
            this.panel5.Controls.Add(this.n3);
            this.panel5.Controls.Add(this.pr4);
            this.panel5.Controls.Add(this.n4);
            this.panel5.Controls.Add(this.pr3);
            this.panel5.Controls.Add(this.n1);
            this.panel5.Controls.Add(this.pr1);
            this.panel5.Controls.Add(this.p4);
            this.panel5.Controls.Add(this.p1);
            this.panel5.Controls.Add(this.p3);
            this.panel5.Controls.Add(this.p2);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(11, 161);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(775, 237);
            this.panel5.TabIndex = 6;
            // 
            // d4
            // 
            this.d4.AutoSize = true;
            this.d4.Location = new System.Drawing.Point(683, 219);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(10, 13);
            this.d4.TabIndex = 39;
            this.d4.Text = ".";
            this.d4.Visible = false;
            // 
            // d3
            // 
            this.d3.AutoSize = true;
            this.d3.Location = new System.Drawing.Point(480, 219);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(10, 13);
            this.d3.TabIndex = 38;
            this.d3.Text = ".";
            this.d3.Visible = false;
            // 
            // d2
            // 
            this.d2.AutoSize = true;
            this.d2.Location = new System.Drawing.Point(250, 219);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(10, 13);
            this.d2.TabIndex = 37;
            this.d2.Text = ".";
            this.d2.Visible = false;
            // 
            // d1
            // 
            this.d1.AutoSize = true;
            this.d1.Location = new System.Drawing.Point(55, 219);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(10, 13);
            this.d1.TabIndex = 36;
            this.d1.Text = ".";
            this.d1.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(458, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 28;
            this.label7.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(237, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(654, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Price";
            // 
            // n2
            // 
            this.n2.AutoSize = true;
            this.n2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n2.Location = new System.Drawing.Point(222, 182);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(123, 24);
            this.n2.TabIndex = 24;
            this.n2.Text = "HeadPhones";
            // 
            // pr2
            // 
            this.pr2.AutoSize = true;
            this.pr2.Location = new System.Drawing.Point(267, 206);
            this.pr2.Name = "pr2";
            this.pr2.Size = new System.Drawing.Size(25, 13);
            this.pr2.TabIndex = 23;
            this.pr2.Text = "500";
            // 
            // n3
            // 
            this.n3.AutoSize = true;
            this.n3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n3.Location = new System.Drawing.Point(435, 182);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(134, 24);
            this.n3.TabIndex = 21;
            this.n3.Text = "Aloe Vera Gel";
            // 
            // pr4
            // 
            this.pr4.AutoSize = true;
            this.pr4.Location = new System.Drawing.Point(684, 206);
            this.pr4.Name = "pr4";
            this.pr4.Size = new System.Drawing.Size(25, 13);
            this.pr4.TabIndex = 20;
            this.pr4.Text = "170";
            // 
            // n4
            // 
            this.n4.AutoSize = true;
            this.n4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n4.Location = new System.Drawing.Point(634, 180);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(121, 24);
            this.n4.TabIndex = 18;
            this.n4.Text = "Baby Lotion";
            // 
            // pr3
            // 
            this.pr3.AutoSize = true;
            this.pr3.Location = new System.Drawing.Point(491, 206);
            this.pr3.Name = "pr3";
            this.pr3.Size = new System.Drawing.Size(25, 13);
            this.pr3.TabIndex = 17;
            this.pr3.Text = "250";
            // 
            // n1
            // 
            this.n1.AutoSize = true;
            this.n1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n1.Location = new System.Drawing.Point(33, 182);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(82, 24);
            this.n1.TabIndex = 15;
            this.n1.Text = "Camera";
            // 
            // pr1
            // 
            this.pr1.AutoSize = true;
            this.pr1.Location = new System.Drawing.Point(71, 206);
            this.pr1.Name = "pr1";
            this.pr1.Size = new System.Drawing.Size(31, 13);
            this.pr1.TabIndex = 14;
            this.pr1.Text = "5000";
            // 
            // p4
            // 
            this.p4.Image = global::SDAProject.Properties.Resources.john;
            this.p4.Location = new System.Drawing.Point(625, 46);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(147, 131);
            this.p4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p4.TabIndex = 13;
            this.p4.TabStop = false;
            this.p4.Click += new System.EventHandler(this.p4_Click);
            // 
            // p1
            // 
            this.p1.Image = global::SDAProject.Properties.Resources.cam;
            this.p1.Location = new System.Drawing.Point(3, 46);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(147, 131);
            this.p1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p1.TabIndex = 12;
            this.p1.TabStop = false;
            this.p1.Click += new System.EventHandler(this.p1_Click);
            // 
            // p3
            // 
            this.p3.Image = global::SDAProject.Properties.Resources.tooth;
            this.p3.Location = new System.Drawing.Point(422, 46);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(147, 131);
            this.p3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p3.TabIndex = 11;
            this.p3.TabStop = false;
            this.p3.Click += new System.EventHandler(this.p3_Click);
            // 
            // p2
            // 
            this.p2.Image = global::SDAProject.Properties.Resources.headset;
            this.p2.Location = new System.Drawing.Point(212, 46);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(147, 131);
            this.p2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p2.TabIndex = 10;
            this.p2.TabStop = false;
            this.p2.Click += new System.EventHandler(this.p2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "SpotLight Deals";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.linkLabel3);
            this.panel3.Controls.Add(this.linkLabel7);
            this.panel3.Controls.Add(this.linkLabel5);
            this.panel3.Controls.Add(this.linkLabel2);
            this.panel3.Controls.Add(this.linkLabel1);
            this.panel3.Location = new System.Drawing.Point(11, 129);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(775, 29);
            this.panel3.TabIndex = 4;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel3.LinkColor = System.Drawing.Color.Black;
            this.linkLabel3.Location = new System.Drawing.Point(569, 5);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(70, 16);
            this.linkLabel3.TabIndex = 12;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "About Us";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel7.LinkColor = System.Drawing.Color.Black;
            this.linkLabel7.Location = new System.Drawing.Point(76, 6);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(48, 16);
            this.linkLabel7.TabIndex = 10;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "Home";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel5.LinkColor = System.Drawing.Color.Black;
            this.linkLabel5.Location = new System.Drawing.Point(190, 6);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(88, 16);
            this.linkLabel5.TabIndex = 10;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "Daily Deals";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(450, 6);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(66, 16);
            this.linkLabel2.TabIndex = 3;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Register";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(341, 5);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(54, 16);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Sign in";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(774, 113);
            this.panel2.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(337, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 31);
            this.label6.TabIndex = 10;
            this.label6.Text = "eMart";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SDAProject.Properties.Resources.emart_logo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // DailyDeals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(800, 506);
            this.Controls.Add(this.panel1);
            this.Name = "DailyDeals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DailyDeals";
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label n2;
        private System.Windows.Forms.Label pr2;
        private System.Windows.Forms.Label n3;
        private System.Windows.Forms.Label pr4;
        private System.Windows.Forms.Label n4;
        private System.Windows.Forms.Label pr3;
        private System.Windows.Forms.Label n1;
        private System.Windows.Forms.Label pr1;
        private System.Windows.Forms.PictureBox p4;
        private System.Windows.Forms.PictureBox p1;
        private System.Windows.Forms.PictureBox p3;
        private System.Windows.Forms.PictureBox p2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label d4;
        private System.Windows.Forms.Label d3;
        private System.Windows.Forms.Label d2;
        private System.Windows.Forms.Label d1;
        private System.Windows.Forms.LinkLabel linkLabel3;
    }
}