﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
            MySqlConnection connection2 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command2;
            MySqlDataAdapter da2;

            String selectQuery2 = "SELECT* FROM picture where  id=1";

            command2 = new MySqlCommand(selectQuery2, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table2 = new DataTable();


            da2.Fill(table2);

            byte[] img2 = (byte[])table2.Rows[0][4];
            MemoryStream ms2 = new MemoryStream(img2);
            pictureBox6.Image = Image.FromStream(ms2);
            n1.Text = table2.Rows[0][1].ToString();
            p1.Text = table2.Rows[0][5].ToString();
            d1.Text = table2.Rows[0][2].ToString();
            da2.Dispose();


            string selectQuery3 = "SELECT* FROM picture where  id=2";

            command2 = new MySqlCommand(selectQuery3, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table3 = new DataTable();

            da2.Fill(table3);

            byte[] img3 = (byte[])table3.Rows[0][4];
            MemoryStream ms3 = new MemoryStream(img3);
            pictureBox5.Image = Image.FromStream(ms3);
            n2.Text = table3.Rows[0][1].ToString();
            p2.Text = table3.Rows[0][5].ToString();
            d2.Text = table3.Rows[0][2].ToString();
            da2.Dispose();




            string selectQuery4 = "SELECT* FROM picture where  id=3";

            command2 = new MySqlCommand(selectQuery4, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table4 = new DataTable();

            da2.Fill(table4);

            byte[] img4 = (byte[])table4.Rows[0][4];
            MemoryStream ms4 = new MemoryStream(img4);
            pictureBox4.Image = Image.FromStream(ms4);
            n3.Text = table4.Rows[0][1].ToString();
            d3.Text = table4.Rows[0][2].ToString();
            p3.Text = table4.Rows[0][5].ToString();

            da2.Dispose();




            string selectQuery5 = "SELECT* FROM picture where  id=4";

            command2 = new MySqlCommand(selectQuery5, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table5 = new DataTable();

            da2.Fill(table5);

            byte[] img5 = (byte[])table5.Rows[0][4];
            MemoryStream ms5 = new MemoryStream(img5);
            pictureBox7.Image = Image.FromStream(ms5);
            n4.Text = table5.Rows[0][1].ToString();
            p4.Text = table5.Rows[0][5].ToString();
            d4.Text = table5.Rows[0][2].ToString();
            da2.Dispose();



        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBox6.Image = Image.FromFile(opf.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(n1.Text!="" && p1.Text!="" &&  d1.Text!="")
            {
                MemoryStream ms = new MemoryStream();
                pictureBox6.Image.Save(ms, pictureBox6.Image.RawFormat);
                byte[] img = ms.ToArray();
                MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command;
                String insertQuery = "DELETE FROM picture WHERE id=1;";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);
                command.ExecuteNonQuery();
                connection.Close();


                insertQuery = "INSERT INTO picture(id,name,Description,quantity,address,price) VALUES(@id,@name,@desc,@qth,@img,@pri)";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);

                command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
                command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
                command.Parameters.Add("@desc", MySqlDbType.Text);
                command.Parameters.Add("@qth", MySqlDbType.Int64);
                command.Parameters.Add("@pri", MySqlDbType.Int64);
                command.Parameters.Add("@img", MySqlDbType.Blob);

                command.Parameters["@id"].Value = 1;
                command.Parameters["@name"].Value = n1.Text;
                command.Parameters["@desc"].Value = d1.Text;
                command.Parameters["@pri"].Value = p1.Text;
                command.Parameters["@img"].Value = img;


                if (command.ExecuteNonQuery() == 1)
                {

                }

                connection.Close();
            }
            MessageBox.Show("Changed\n");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminSignIn h= new AdminSignIn(0);
            this.Hide();
            h.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (n2.Text != "" && p2.Text != "" && d2.Text != "")
            {
                MemoryStream ms = new MemoryStream();
                pictureBox5.Image.Save(ms, pictureBox5.Image.RawFormat);
                byte[] img = ms.ToArray();
                MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command;
                String insertQuery = "DELETE FROM picture WHERE id=2;";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);
                command.ExecuteNonQuery();
                connection.Close();


                insertQuery = "INSERT INTO picture(id,name,Description,quantity,address,price) VALUES(@id,@name,@desc,@qth,@img,@pri)";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);

                command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
                command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
                command.Parameters.Add("@desc", MySqlDbType.Text);
                command.Parameters.Add("@qth", MySqlDbType.Int64);
                command.Parameters.Add("@pri", MySqlDbType.Int64);
                command.Parameters.Add("@img", MySqlDbType.Blob);

                command.Parameters["@id"].Value = 2;
                command.Parameters["@name"].Value = n2.Text;
                command.Parameters["@desc"].Value = d2.Text;
                command.Parameters["@pri"].Value = p2.Text;
                command.Parameters["@img"].Value = img;


                if (command.ExecuteNonQuery() == 1)
                {

                }

                connection.Close();
            }

            MessageBox.Show("Changed\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (n3.Text != "" && p3.Text != "" && d3.Text != "")
            {
                MemoryStream ms = new MemoryStream();
                pictureBox4.Image.Save(ms, pictureBox4.Image.RawFormat);
                byte[] img = ms.ToArray();
                MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command;
                String insertQuery = "DELETE FROM picture WHERE id=3;";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);
                command.ExecuteNonQuery();
                connection.Close();


                insertQuery = "INSERT INTO picture(id,name,Description,quantity,address,price) VALUES(@id,@name,@desc,@qth,@img,@pri)";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);

                command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
                command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
                command.Parameters.Add("@desc", MySqlDbType.Text);
                command.Parameters.Add("@qth", MySqlDbType.Int64);
                command.Parameters.Add("@pri", MySqlDbType.Int64);
                command.Parameters.Add("@img", MySqlDbType.Blob);

                command.Parameters["@id"].Value = 3;
                command.Parameters["@name"].Value = n3.Text;
                command.Parameters["@desc"].Value = d3.Text;
                command.Parameters["@pri"].Value = p3.Text;
                command.Parameters["@img"].Value = img;


                if (command.ExecuteNonQuery() == 1)
                {

                }

                connection.Close();
                MessageBox.Show("Changed\n");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (n4.Text != "" && p4.Text != "" && d4.Text != "")
            {
                MemoryStream ms = new MemoryStream();
                pictureBox7.Image.Save(ms, pictureBox7.Image.RawFormat);
                byte[] img = ms.ToArray();
                MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command;
                String insertQuery = "DELETE FROM picture WHERE id=4;";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);
                command.ExecuteNonQuery();
                connection.Close();


                insertQuery = "INSERT INTO picture(id,name,Description,quantity,address,price) VALUES(@id,@name,@desc,@qth,@img,@pri)";
                connection.Open();
                command = new MySqlCommand(insertQuery, connection);

                command.Parameters.Add("@id", MySqlDbType.VarChar, 20);
                command.Parameters.Add("@name", MySqlDbType.VarChar, 200);
                command.Parameters.Add("@desc", MySqlDbType.Text);
                command.Parameters.Add("@qth", MySqlDbType.Int64);
                command.Parameters.Add("@pri", MySqlDbType.Int64);
                command.Parameters.Add("@img", MySqlDbType.Blob);

                command.Parameters["@id"].Value = 4;
                command.Parameters["@name"].Value = n4.Text;
                command.Parameters["@desc"].Value = d4.Text;
                command.Parameters["@pri"].Value = p4.Text;
                command.Parameters["@img"].Value = img;


                if (command.ExecuteNonQuery() == 1)
                {

                }

                connection.Close();
            }
            MessageBox.Show("Changed\n");
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBox5.Image = Image.FromFile(opf.FileName);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBox4.Image = Image.FromFile(opf.FileName);
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBox7.Image = Image.FromFile(opf.FileName);
            }
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.Show();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminOrder o = new AdminOrder();
            this.Hide();
            o.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminDeals d = new AdminDeals();
            this.Hide();
            d.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminAbout a = new AdminAbout();
            this.Hide();
            a.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pictureBox2.Visible == true)
            {
                pictureBox2.Visible = false;
                pictureBox8.Visible = true;
            }
            else if (pictureBox8.Visible == true)
            {
                pictureBox8.Visible = false;
                pictureBox9.Visible = true;
            }
            else if (pictureBox9.Visible == true)
            {
                pictureBox9.Visible = false;
                pictureBox10.Visible = true;
            }
            else if (pictureBox10.Visible == true)
            {
                pictureBox10.Visible = false;
                pictureBox11.Visible = true;
            }
            else if (pictureBox11.Visible == true)
            {
                pictureBox11.Visible = false;
                pictureBox2.Visible = true;
            }
        }
    }
}
