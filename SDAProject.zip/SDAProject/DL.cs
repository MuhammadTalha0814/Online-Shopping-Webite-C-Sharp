﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace SDAProject
{
    internal class DL
    {
        public static ArrayList users = new ArrayList();

        public static void addstd(DTO std)
        {
            users.Add(std);

            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=eMart";
            string query = "INSERT INTO customers(FirstName,LastName,email,Password,Phone) VALUES ('" + std.Firstname + "', '" + std.LastName + "', '" + std.EmailAddress + "', '" + std.Password + "', '" +std.Phone + "')";
            MySqlConnection databaseconnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseconnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;
            try
            {
                databaseconnection.Open();
                reader = commandDatabase.ExecuteReader();



            }
            catch (Exception ex)
            {
                // Show any error message.
                //MessageBox.Show(ex.Message);
            }
        }

        public static DTO Isvalid(DTO std)
        {
            foreach (DTO u in users)
                if (u._EmailAddress.Equals(std._EmailAddress) && u._password.Equals(std._password))
                    return u;
            return null;


        }
    }
}
