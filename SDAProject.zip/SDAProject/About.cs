﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class About : Form
    {
        int pid;
        public About(int id)
        {
            InitializeComponent();
            pid = id;
            MySqlConnection connection2 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command2;
            MySqlDataAdapter da2;

            String selectQuery2 = "SELECT* FROM about";

            command2 = new MySqlCommand(selectQuery2, connection2);

            da2 = new MySqlDataAdapter(command2);

            DataTable table2 = new DataTable();

            da2.Fill(table2);
            
            d1.Text = table2.Rows[0][0].ToString();
            da2.Dispose();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1(pid);
            this.Hide();
            f.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 f = new Form1(pid);
            this.Hide();
            f.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DailyDeals f = new DailyDeals(pid);
            this.Hide();
            f.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home f = new Home(pid);
            this.Hide();
            f.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up f = new Sign_Up(pid);
            this.Hide();
            f.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
