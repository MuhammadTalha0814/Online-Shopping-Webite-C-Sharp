﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SDAProject
{
    public partial class Home : Form
    {
        int pid;
        public Home(int p)
        {
            InitializeComponent();
            pid = p;
        }

        private void LOGO_Click(object sender, EventArgs e)
        {
            Form1 f=new Form1(pid);
            this.Hide();
            f.Show();
        }

        private void Register_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Sign_Up f = new Sign_Up(pid);
            this.Hide();
            f.Show();
        }

        private void MoveToSignIn_Click(object sender, EventArgs e)
        {
            string emailcheck = "{";
            string passwordcheck = "{";
            bool flag = false;
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand cmd;
            MySqlDataReader mdr;

            connection.Open();

            string query = "SELECT * FROM customers WHERE email='" + USERNAME.Text + "'";
            cmd = new MySqlCommand(query, connection);

            mdr = cmd.ExecuteReader();

            if (mdr.Read())
            {
                emailcheck = mdr.GetString("email");
                passwordcheck = mdr.GetString("password");
                flag = true;
            }
            else
            {
                MessageBox.Show("No Record Of This ID");

            }           
            if (flag == true)
            {
                if (emailcheck == USERNAME.Text && passwordcheck == PASSWORD.Text)
                {
                    
                    Form1 form = new Form1(pid);
                    this.Hide();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("User is Invalid");
                }
            }

            connection.Close();

            USERNAME.Clear();
            PASSWORD.Clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 f = new Form1(pid);
            this.Hide();
            f.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminSignIn h = new AdminSignIn(pid);
            this.Hide();
            h.Show();
        }
    }
}
