﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace SDAProject
{
    public partial class Buy_Now : Form
    {
        string ep;
        int id;
        public Buy_Now(string email,int i)
        {
            InitializeComponent();
            ep= email;
            id = i;

            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            MySqlDataAdapter da;

            String selectQuery = "SELECT* FROM picture where id=" + id;
            command = new MySqlCommand(selectQuery, connection);

            da = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            da.Fill(table);

            qn.Text = table.Rows[0][3].ToString();
            
            int b = Int32.Parse(qn.Text);
            pp.Text = table.Rows[0][5].ToString();
            int c= Int32.Parse(pp.Text);
            
            int t = b * c;

            la.Text = t.ToString();

          



            da.Dispose();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1(id);
            this.Hide();
            f.Show();
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home f = new Home(id);
            this.Hide();
            f.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up f = new Sign_Up(id);
            this.Hide();
            f.Show();
        }
        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DailyDeals p = new DailyDeals(id);
            this.Hide();
            p.Show();
        }

        

        private void OK_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
            MySqlCommand command;
            MySqlDataAdapter da;

            String selectQuery = "SELECT* FROM customers where email='" + ep+"';";

            command = new MySqlCommand(selectQuery, connection);

            da = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            da.Fill(table);
            if(a1.Text!="")
            {
                FIRSTNAME.Text = table.Rows[0][0].ToString();
                LASTNAME.Text = table.Rows[0][1].ToString();
                PHONE.Text = table.Rows[0][4].ToString();
                ADDRESS.Text = a1.Text;
            }

            da.Dispose();
        }

       

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch=e.KeyChar;
            if(!Char.IsDigit(ch) && ch!=8 && ch!=46)
            {
                e.Handled = true;
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home h = new Home(id);
            this.Hide();
            h.Show();
        }

        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up h=new Sign_Up(id);
            this.Hide();
            h.Show();
        }

        private void linkLabel4_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DailyDeals h = new DailyDeals(id);
            this.Hide();
            h.Show();
        }

       

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://us.norton.com/");
        }

        private void BUY_Click(object sender, EventArgs e)
        {
            if(ADDRESS.Text!="")
            {
                MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command;
                MySqlDataAdapter da;

                String selectQuery = "SELECT* FROM picture where id=" + id;
                command = new MySqlCommand(selectQuery, connection);

                da = new MySqlDataAdapter(command);

                DataTable table = new DataTable();

                da.Fill(table);
                byte[] img = (byte[])table.Rows[0][4];
                qn.Text = table.Rows[0][3].ToString();

                int b = Int32.Parse(qn.Text);
                pp.Text = table.Rows[0][5].ToString();
                int c = Int32.Parse(pp.Text);

                int t = b * c;

                la.Text = t.ToString();


                MySqlConnection connection1 = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=eMart");
                MySqlCommand command1;
                string insertQuery = "INSERT INTO order_place(FirstName,LastName,address,phone,id,pic,quantity,PerItemPrice,TotalPrice) VALUES(@fn,@ln,@ad,@p,@pid,@img,@q,@pp,@tp)";
                connection1.Open();
                command1 = new MySqlCommand(insertQuery, connection1);

                command1.Parameters.Add("@fn", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@ln", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@ad", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@p", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@pid", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@q", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@pp", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@tp", MySqlDbType.VarChar, 200);
                command1.Parameters.Add("@img", MySqlDbType.Blob);

                command1.Parameters["@fn"].Value = FIRSTNAME.Text;
                command1.Parameters["@ln"].Value = LASTNAME.Text;
                command1.Parameters["@ad"].Value = ADDRESS.Text;
                command1.Parameters["@p"].Value = PHONE.Text;
                command1.Parameters["@pid"].Value = id;
                command1.Parameters["@q"].Value = b;
                command1.Parameters["@pp"].Value = c;
                command1.Parameters["@tp"].Value = b*c;
                command1.Parameters["@img"].Value = img;


                if (command1.ExecuteNonQuery() == 1)
                {

                }

                connection1.Close();





                da.Dispose();
                MessageBox.Show("Your Order Has Been Placed\nThanks For Shopping");
                Form1 f = new Form1(id);
                this.Hide();
                f.Show();
            }
            else MessageBox.Show("Please Enter Your Address");
           

        }
    }
}
